# Roadmap

- [x] Add clear proceed and leave choices to the welcome screen.
- [x] Add the authenticated study reader with progress and reflections.
- [x] Add profile editing and spouse linking.
- [x] Add the administrator workspace.
- [ ] Verify the signed-in member flow in the live preview.