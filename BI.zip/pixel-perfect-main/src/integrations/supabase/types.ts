export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      contact_messages: {
        Row: {
          created_at: string
          email: string
          id: string
          message: string
          name: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
        }
        Relationships: []
      }
      couple_invites: {
        Row: {
          code: string
          created_at: string
          inviter_id: string
          used_at: string | null
        }
        Insert: {
          code?: string
          created_at?: string
          inviter_id?: string
          used_at?: string | null
        }
        Update: {
          code?: string
          created_at?: string
          inviter_id?: string
          used_at?: string | null
        }
        Relationships: []
      }
      couples: {
        Row: {
          created_at: string
          id: string
          status: string
        }
        Insert: {
          created_at?: string
          id?: string
          status?: string
        }
        Update: {
          created_at?: string
          id?: string
          status?: string
        }
        Relationships: []
      }
      email_signups: {
        Row: {
          created_at: string
          email: string
          id: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
        }
        Relationships: []
      }
      event_registrations: {
        Row: {
          created_at: string
          event_id: string
          id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          event_id: string
          id?: string
          user_id?: string
        }
        Update: {
          created_at?: string
          event_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_registrations_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          capacity: number | null
          cover_url: string | null
          created_at: string
          description: string | null
          ends_at: string | null
          id: string
          location: string | null
          price_cents: number
          starts_at: string
          title: string
        }
        Insert: {
          capacity?: number | null
          cover_url?: string | null
          created_at?: string
          description?: string | null
          ends_at?: string | null
          id?: string
          location?: string | null
          price_cents?: number
          starts_at: string
          title: string
        }
        Update: {
          capacity?: number | null
          cover_url?: string | null
          created_at?: string
          description?: string | null
          ends_at?: string | null
          id?: string
          location?: string | null
          price_cents?: number
          starts_at?: string
          title?: string
        }
        Relationships: []
      }
      journal_entries: {
        Row: {
          body: string
          created_at: string
          id: string
          study_day_id: string | null
          user_id: string
          visibility: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          study_day_id?: string | null
          user_id?: string
          visibility?: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          study_day_id?: string | null
          user_id?: string
          visibility?: string
        }
        Relationships: [
          {
            foreignKeyName: "journal_entries_study_day_id_fkey"
            columns: ["study_day_id"]
            isOneToOne: false
            referencedRelation: "study_days"
            referencedColumns: ["id"]
          },
        ]
      }
      posts: {
        Row: {
          access: string
          body_md: string
          category: string | null
          cover_url: string | null
          excerpt: string | null
          id: string
          published_at: string | null
          slug: string
          status: string
          tags: string[]
          title: string
        }
        Insert: {
          access?: string
          body_md?: string
          category?: string | null
          cover_url?: string | null
          excerpt?: string | null
          id?: string
          published_at?: string | null
          slug: string
          status?: string
          tags?: string[]
          title: string
        }
        Update: {
          access?: string
          body_md?: string
          category?: string | null
          cover_url?: string | null
          excerpt?: string | null
          id?: string
          published_at?: string | null
          slug?: string
          status?: string
          tags?: string[]
          title?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          couple_id: string | null
          created_at: string
          first_name: string
          gender: Database["public"]["Enums"]["gender"] | null
          id: string
          last_name: string
          notify_email: boolean
          notify_sms: boolean
          phone: string | null
          phone_verified: boolean
        }
        Insert: {
          avatar_url?: string | null
          couple_id?: string | null
          created_at?: string
          first_name?: string
          gender?: Database["public"]["Enums"]["gender"] | null
          id: string
          last_name?: string
          notify_email?: boolean
          notify_sms?: boolean
          phone?: string | null
          phone_verified?: boolean
        }
        Update: {
          avatar_url?: string | null
          couple_id?: string | null
          created_at?: string
          first_name?: string
          gender?: Database["public"]["Enums"]["gender"] | null
          id?: string
          last_name?: string
          notify_email?: boolean
          notify_sms?: boolean
          phone?: string | null
          phone_verified?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "profiles_couple_id_fkey"
            columns: ["couple_id"]
            isOneToOne: false
            referencedRelation: "couples"
            referencedColumns: ["id"]
          },
        ]
      }
      purchases: {
        Row: {
          created_at: string
          id: string
          study_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          study_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          study_id?: string
          user_id?: string
        }
        Relationships: []
      }
      studies: {
        Row: {
          audience: Database["public"]["Enums"]["study_audience"]
          cover_url: string | null
          created_at: string
          description: string | null
          duration_label: string | null
          id: string
          included_in_membership: boolean
          pdf_url: string | null
          price_cents: number
          slug: string
          sort: number
          status: string
          stripe_price_id: string | null
          subtitle: string | null
          title: string
        }
        Insert: {
          audience?: Database["public"]["Enums"]["study_audience"]
          cover_url?: string | null
          created_at?: string
          description?: string | null
          duration_label?: string | null
          id?: string
          included_in_membership?: boolean
          pdf_url?: string | null
          price_cents?: number
          slug: string
          sort?: number
          status?: string
          stripe_price_id?: string | null
          subtitle?: string | null
          title: string
        }
        Update: {
          audience?: Database["public"]["Enums"]["study_audience"]
          cover_url?: string | null
          created_at?: string
          description?: string | null
          duration_label?: string | null
          id?: string
          included_in_membership?: boolean
          pdf_url?: string | null
          price_cents?: number
          slug?: string
          sort?: number
          status?: string
          stripe_price_id?: string | null
          subtitle?: string | null
          title?: string
        }
        Relationships: []
      }
      study_days: {
        Row: {
          body_md: string
          challenge_md: string | null
          day_number: number
          id: string
          is_sample: boolean
          reflection_questions: Json
          scripture_refs: string | null
          title: string
          video_id: string | null
          week_id: string
        }
        Insert: {
          body_md?: string
          challenge_md?: string | null
          day_number: number
          id?: string
          is_sample?: boolean
          reflection_questions?: Json
          scripture_refs?: string | null
          title: string
          video_id?: string | null
          week_id: string
        }
        Update: {
          body_md?: string
          challenge_md?: string | null
          day_number?: number
          id?: string
          is_sample?: boolean
          reflection_questions?: Json
          scripture_refs?: string | null
          title?: string
          video_id?: string | null
          week_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "study_days_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "study_days_week_id_fkey"
            columns: ["week_id"]
            isOneToOne: false
            referencedRelation: "study_weeks"
            referencedColumns: ["id"]
          },
        ]
      }
      study_progress: {
        Row: {
          completed_at: string
          study_day_id: string
          user_id: string
        }
        Insert: {
          completed_at?: string
          study_day_id: string
          user_id?: string
        }
        Update: {
          completed_at?: string
          study_day_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "study_progress_study_day_id_fkey"
            columns: ["study_day_id"]
            isOneToOne: false
            referencedRelation: "study_days"
            referencedColumns: ["id"]
          },
        ]
      }
      study_weeks: {
        Row: {
          id: string
          study_id: string
          summary: string | null
          title: string
          week_number: number
        }
        Insert: {
          id?: string
          study_id: string
          summary?: string | null
          title: string
          week_number: number
        }
        Update: {
          id?: string
          study_id?: string
          summary?: string | null
          title?: string
          week_number?: number
        }
        Relationships: [
          {
            foreignKeyName: "study_weeks_study_id_fkey"
            columns: ["study_id"]
            isOneToOne: false
            referencedRelation: "studies"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          created_at: string
          current_period_end: string | null
          id: string
          status: string
          user_id: string
        }
        Insert: {
          created_at?: string
          current_period_end?: string | null
          id?: string
          status?: string
          user_id: string
        }
        Update: {
          created_at?: string
          current_period_end?: string | null
          id?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      videos: {
        Row: {
          access: string
          description: string | null
          embed_url: string
          id: string
          published_at: string
          thumbnail_url: string | null
          title: string
        }
        Insert: {
          access?: string
          description?: string | null
          embed_url: string
          id?: string
          published_at?: string
          thumbnail_url?: string | null
          title: string
        }
        Update: {
          access?: string
          description?: string | null
          embed_url?: string
          id?: string
          published_at?: string
          thumbnail_url?: string | null
          title?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      accept_couple_invite: { Args: { _code: string }; Returns: string }
      admin_stats: { Args: never; Returns: Json }
      get_post: {
        Args: { _slug: string }
        Returns: {
          access: string
          body_md: string
          category: string
          cover_url: string
          excerpt: string
          id: string
          locked: boolean
          published_at: string
          slug: string
          tags: string[]
          title: string
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      has_study_access: {
        Args: { _study: string; _uid: string }
        Returns: boolean
      }
      is_member: { Args: { _uid: string }; Returns: boolean }
      list_posts: {
        Args: never
        Returns: {
          access: string
          category: string
          cover_url: string
          excerpt: string
          id: string
          published_at: string
          slug: string
          tags: string[]
          title: string
        }[]
      }
      my_couple: { Args: never; Returns: string }
      study_outline: {
        Args: { _study: string }
        Returns: {
          day_number: number
          id: string
          is_sample: boolean
          scripture_refs: string
          title: string
          week_id: string
        }[]
      }
      unlink_couple: { Args: never; Returns: undefined }
    }
    Enums: {
      app_role: "member" | "admin"
      gender: "husband" | "wife"
      study_audience: "couples" | "husbands" | "wives" | "everyone"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["member", "admin"],
      gender: ["husband", "wife"],
      study_audience: ["couples", "husbands", "wives", "everyone"],
    },
  },
} as const
