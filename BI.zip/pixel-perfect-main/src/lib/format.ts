export const price = (cents: number) => (cents === 0 ? "Free" : `$${(cents / 100).toFixed(cents % 100 ? 2 : 0)}`);
export const date = (d: string) =>
  new Date(d).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
export const audienceLabel: Record<string, string> = {
  couples: "For Couples",
  husbands: "For Husbands",
  wives: "For Wives",
  everyone: "For Everyone",
};
export const SITE = "Biblical Intimacy";
