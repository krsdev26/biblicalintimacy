import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import ReactMarkdown from "react-markdown";
import { ArrowRight, ExternalLink, Menu, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { SITE, audienceLabel, price } from "@/lib/format";

const nav = [
  { to: "/studies", label: "Studies" },
  { to: "/blog", label: "Blog" },
  { to: "/events", label: "Intensives" },
  { to: "/pricing", label: "Pricing" },
  { to: "/about", label: "About" },
] as const;

export function SiteHeader() {
  const { user, isAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const signOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/", replace: true });
  };
  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <Link to="/" className="font-serif text-2xl font-semibold text-primary">
          {SITE}
        </Link>
        <nav className="hidden items-center gap-7 text-sm md:flex">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className="text-foreground/75 hover:text-primary" activeProps={{ className: "text-primary font-medium" }}>
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          {user ? (
            <>
              {isAdmin && <Button asChild variant="ghost" size="sm"><Link to="/admin">Admin</Link></Button>}
              <Button asChild variant="ghost" size="sm"><Link to="/dashboard">Dashboard</Link></Button>
              <Button variant="outline" size="sm" onClick={signOut}>Sign out</Button>
            </>
          ) : (
            <>
              <Button asChild variant="ghost" size="sm"><Link to="/auth">Sign in</Link></Button>
              <Button asChild size="sm"><Link to="/auth" search={{ mode: "signup" }}>Join</Link></Button>
            </>
          )}
        </div>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <div className="border-t bg-background px-5 py-4 md:hidden" onClick={() => setOpen(false)}>
          <div className="flex flex-col gap-3">
            {nav.map((n) => <Link key={n.to} to={n.to} className="py-1">{n.label}</Link>)}
            {user ? (
              <>
                <Link to="/dashboard" className="py-1">Dashboard</Link>
                <Link to="/profile" className="py-1">Profile</Link>
                {isAdmin && <Link to="/admin" className="py-1">Admin</Link>}
                <Button variant="outline" onClick={signOut}>Sign out</Button>
              </>
            ) : (
              <Button asChild><Link to="/auth">Sign in / Join</Link></Button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-forest text-primary-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <p className="font-serif text-2xl">{SITE}</p>
          <p className="mt-3 max-w-sm text-sm text-primary-foreground/70">
            Scripture-based teaching for married couples on intimacy, covenant, and growing together in Christ.
          </p>
        </div>
        <div className="flex flex-col gap-2 text-sm text-primary-foreground/80">
          <Link to="/studies">Studies</Link><Link to="/blog">Blog</Link><Link to="/events">Intensives</Link><Link to="/pricing">Pricing</Link>
        </div>
        <div className="flex flex-col gap-2 text-sm text-primary-foreground/80">
          <Link to="/about">About</Link><Link to="/faq">FAQ</Link><Link to="/contact">Contact</Link><Link to="/privacy">Privacy</Link><Link to="/terms">Terms</Link>
        </div>
      </div>
      <p className="border-t border-primary-foreground/10 py-5 text-center text-xs text-primary-foreground/60">
        © {new Date().getFullYear()} {SITE}. For married adults 18+.
      </p>
    </footer>
  );
}

export function AgeGate() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!localStorage.getItem("bi-age-ok")) setOpen(true);
  }, []);
  return (
    <Dialog open={open}>
      <DialogContent className="max-w-md [&>button]:hidden" onInteractOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <p className="eyebrow">Welcome</p>
          <DialogTitle className="font-serif text-3xl">Before you continue</DialogTitle>
          <DialogDescription className="pt-2 text-base leading-relaxed">
            This site contains frank biblical teaching on marital intimacy intended for married adults 18+.
          </DialogDescription>
        </DialogHeader>
        <div className="mt-2 grid gap-3">
          <Button size="lg" onClick={() => { localStorage.setItem("bi-age-ok", "1"); setOpen(false); }}>
            Proceed to Biblical Intimacy <ArrowRight />
          </Button>
          <Button asChild size="lg" variant="outline">
            <a href="https://www.biblegateway.com">Leave this site <ExternalLink /></a>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function Scripture({ children, reference }: { children: ReactNode; reference?: string }) {
  return (
    <figure className="my-6 border-l-[3px] border-gold py-1 pl-5">
      <blockquote className="font-serif text-2xl italic leading-snug text-secondary-foreground">{children}</blockquote>
      {reference && <figcaption className="mt-2 text-xs font-semibold uppercase tracking-[0.2em] text-gold">{reference}</figcaption>}
    </figure>
  );
}

export function Markdown({ children }: { children: string }) {
  return <div className="prose-devotional"><ReactMarkdown>{children}</ReactMarkdown></div>;
}

export function PageHeader({ eyebrow, title, children }: { eyebrow?: string; title: string; children?: ReactNode }) {
  return (
    <section className="mx-auto max-w-4xl px-5 pt-16 pb-10 text-center">
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <h1 className="mt-3 text-5xl text-primary md:text-6xl">{title}</h1>
      {children && <div className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">{children}</div>}
    </section>
  );
}

type Study = { id: string; slug: string; title: string; subtitle: string | null; audience: string; duration_label: string | null; price_cents: number; cover_url: string | null };
export function StudyCard({ s }: { s: Study }) {
  return (
    <div className="group flex flex-col overflow-hidden rounded-lg border bg-card shadow-soft">
      <div className="flex aspect-[4/3] items-end bg-forest p-5">
        {s.cover_url ? <img src={s.cover_url} alt="" className="h-full w-full object-cover" loading="lazy" /> : (
          <p className="font-serif text-2xl leading-tight text-primary-foreground">{s.title}</p>
        )}
      </div>
      <div className="flex flex-1 flex-col p-5">
        <p className="eyebrow">{audienceLabel[s.audience]}</p>
        <h3 className="mt-2 text-2xl text-primary">{s.title}</h3>
        {s.subtitle && <p className="mt-1 text-sm text-muted-foreground">{s.subtitle}</p>}
        <div className="mt-auto flex items-center justify-between pt-5 text-sm">
          <span className="text-muted-foreground">{s.duration_label} · <span className="font-medium text-foreground">{price(s.price_cents)}</span></span>
          <Button asChild size="sm" variant="outline"><Link to="/studies/$slug" params={{ slug: s.slug }}>Preview</Link></Button>
        </div>
      </div>
    </div>
  );
}

export function EmailSignup() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.from("email_signups").insert({ email: email.trim().toLowerCase() });
    setBusy(false);
    if (error && !error.message.includes("duplicate")) { toast.error("Could not sign up. Please try again."); return; }
    toast.success("Thank you! You're on the list.");
    setEmail("");
  };
  return (
    <form onSubmit={submit} className="mx-auto flex max-w-md flex-col gap-2 sm:flex-row">
      <Input type="email" required maxLength={255} placeholder="Your email" value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 bg-card" />
      <Button type="submit" size="lg" disabled={busy}>Subscribe</Button>
    </form>
  );
}
