import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Scripture } from "@/components/site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Biblical Intimacy" },
      { name: "description", content: "Why we teach on biblical intimacy and who this ministry is for." },
      { property: "og:title", content: "About — Biblical Intimacy" },
      { property: "og:description", content: "Why we teach on biblical intimacy and who this ministry is for." },
    ],
  }),
  component: () => (
    <>
      <PageHeader eyebrow="About" title="Why we exist" />
      <div className="mx-auto max-w-2xl px-5 text-lg leading-relaxed">
        <p>Biblical Intimacy began with a simple conviction: God is not silent about the marriage bed, and His Church shouldn't be either.</p>
        <Scripture reference="Hebrews 13:4">Let marriage be held in honor among all, and let the marriage bed be undefiled.</Scripture>
        <p className="mt-4">We create studies, articles, and live intensives that help husbands and wives understand God's good design — modestly, reverently, and without shame. Everything we teach is anchored in Scripture.</p>
        <p className="mt-4 text-muted-foreground">(Placeholder: add your founders' story and photos here.)</p>
      </div>
    </>
  ),
});
