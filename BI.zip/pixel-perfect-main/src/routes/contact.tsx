import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { PageHeader } from "@/components/site";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Biblical Intimacy" },
      { name: "description", content: "Send us a question or prayer request." },
      { property: "og:title", content: "Contact — Biblical Intimacy" },
      { property: "og:description", content: "Send us a question or prayer request." },
    ],
  }),
  component: Contact,
});

const schema = z.object({ name: z.string().trim().min(1).max(200), email: z.string().trim().email().max(255), message: z.string().trim().min(1).max(5000) });

function Contact() {
  const [f, setF] = useState({ name: "", email: "", message: "" });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const p = schema.safeParse(f);
    if (!p.success) { toast.error("Please fill in all fields with a valid email."); return; }
    const { error } = await supabase.from("contact_messages").insert(p.data as { name: string; email: string; message: string });
    if (error) { toast.error("Could not send. Please try again."); return; }
    toast.success("Thank you — we'll be in touch.");
    setF({ name: "", email: "", message: "" });
  };
  return (
    <>
      <PageHeader eyebrow="Contact" title="We'd love to hear from you" />
      <form onSubmit={submit} className="mx-auto max-w-lg space-y-3 px-5">
        <Input placeholder="Name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <Input type="email" placeholder="Email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        <Textarea rows={6} placeholder="Message" value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} />
        <Button type="submit" className="w-full" size="lg">Send message</Button>
      </form>
    </>
  );
}
