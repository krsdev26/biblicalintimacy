import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { EmailSignup, Scripture, StudyCard } from "@/components/site";
import { supabase } from "@/integrations/supabase/client";
import { price } from "@/lib/format";
import hero from "@/assets/hero.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Biblical Intimacy — Scripture-based help for married couples" },
      { name: "description", content: "Bible studies, teaching, and live intensives on God's design for marriage and intimacy." },
      { property: "og:title", content: "Biblical Intimacy" },
      { property: "og:description", content: "Bible studies, teaching, and live intensives on God's design for marriage and intimacy." },
    ],
  }),
  component: Home,
});

function Home() {
  const studies = useQuery({ queryKey: ["studies", "featured"], queryFn: async () => (await supabase.from("studies").select("*").eq("status", "published").order("sort").limit(3)).data ?? [] });
  const posts = useQuery({ queryKey: ["posts"], queryFn: async () => (await supabase.rpc("list_posts")).data ?? [] });
  const events = useQuery({ queryKey: ["events"], queryFn: async () => (await supabase.from("events").select("*").gte("starts_at", new Date().toISOString()).order("starts_at")).data ?? [] });

  return (
    <>
      <section className="relative overflow-hidden">
        <img src={hero} alt="An open Bible beside two wedding rings" width={1600} height={1008} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/95 via-primary/75 to-primary/20" />
        <div className="relative mx-auto max-w-6xl px-5 py-28 md:py-40">
          <p className="eyebrow">For married couples</p>
          <h1 className="mt-4 max-w-2xl text-5xl leading-[1.05] text-primary-foreground md:text-7xl">
            Delight in the marriage God designed.
          </h1>
          <p className="mt-6 max-w-lg text-lg text-primary-foreground/85">
            Frank, reverent, Scripture-rooted teaching on intimacy, covenant, and growing closer to Christ — together.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Button asChild size="lg" variant="gold"><Link to="/studies">Explore the studies</Link></Button>
            <Button asChild size="lg" variant="heroOutline"><Link to="/pricing">Become a member</Link></Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-5 py-20 text-center">
        <p className="eyebrow">Our mission</p>
        <h2 className="mt-3 text-4xl text-primary">Replacing shame with truth, and silence with delight.</h2>
        <p className="mt-5 text-muted-foreground">
          Many Christian couples were never taught what God actually says about marital intimacy. We open the Word together — honestly and modestly — so husbands and wives can walk in freedom.
        </p>
        <div className="mx-auto max-w-xl text-left">
          <Scripture reference="Genesis 2:25">And the man and his wife were both naked and were not ashamed.</Scripture>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5">
        <div className="flex items-end justify-between">
          <div><p className="eyebrow">Bible studies</p><h2 className="mt-2 text-4xl text-primary">Featured studies</h2></div>
          <Link to="/studies" className="text-sm text-primary underline">View all</Link>
        </div>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {studies.data?.map((s) => <StudyCard key={s.id} s={s} />)}
        </div>
      </section>

      <section className="mx-auto mt-24 grid max-w-6xl gap-12 px-5 md:grid-cols-2">
        <div>
          <p className="eyebrow">From the blog</p>
          <h2 className="mt-2 text-4xl text-primary">Latest writing</h2>
          <div className="mt-6 divide-y">
            {posts.data?.slice(0, 3).map((p) => (
              <Link key={p.id} to="/blog/$slug" params={{ slug: p.slug }} className="block py-5 hover:text-primary">
                <p className="text-xs uppercase tracking-widest text-muted-foreground">{p.category} {p.access === "members" && "· Members"}</p>
                <h3 className="mt-1 text-2xl">{p.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{p.excerpt}</p>
              </Link>
            ))}
          </div>
        </div>
        <div>
          <p className="eyebrow">Live intensives</p>
          <h2 className="mt-2 text-4xl text-primary">Upcoming</h2>
          <div className="mt-6 space-y-4">
            {events.data?.slice(0, 3).map((e) => (
              <Link key={e.id} to="/events" className="flex gap-5 rounded-lg border bg-card p-5 shadow-soft">
                <div className="w-14 shrink-0 text-center">
                  <p className="text-xs uppercase text-gold">{new Date(e.starts_at).toLocaleString("en-US", { month: "short" })}</p>
                  <p className="font-serif text-3xl text-primary">{new Date(e.starts_at).getDate()}</p>
                </div>
                <div><h3 className="text-xl">{e.title}</h3><p className="text-sm text-muted-foreground">{e.location} · {price(e.price_cents)}</p></div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto mt-24 max-w-6xl px-5">
        <div className="rounded-xl bg-forest px-8 py-14 text-center text-primary-foreground">
          <p className="eyebrow">Membership</p>
          <h2 className="mt-3 text-4xl">Every study, video, and members-only post.</h2>
          <p className="mx-auto mt-3 max-w-lg text-primary-foreground/80">One membership for your whole marriage — link your account with your spouse's and grow together.</p>
          <Button asChild size="lg" variant="gold" className="mt-8"><Link to="/pricing">See pricing</Link></Button>
        </div>
      </section>

      <section className="mx-auto mt-24 max-w-2xl px-5 text-center">
        <h2 className="text-3xl text-primary">Encouragement in your inbox</h2>
        <p className="mb-6 mt-2 text-muted-foreground">A short, Scripture-filled note for your marriage each week.</p>
        <EmailSignup />
      </section>
    </>
  );
}

