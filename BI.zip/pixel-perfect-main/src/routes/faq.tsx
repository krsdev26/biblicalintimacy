import { createFileRoute } from "@tanstack/react-router";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { PageHeader } from "@/components/site";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Biblical Intimacy" },
      { name: "description", content: "Answers to common questions about studies, membership, and spouse linking." },
      { property: "og:title", content: "FAQ — Biblical Intimacy" },
      { property: "og:description", content: "Answers to common questions about studies, membership, and spouse linking." },
    ],
  }),
  component: Faq,
});

const faqs = [
  ["Who is this for?", "Married Christian adults (18+) who want to understand God's design for marriage and intimacy."],
  ["Is the content explicit?", "No. Our teaching is frank and honest, but always modest and Scripture-centered. There is no suggestive imagery."],
  ["How does spouse linking work?", "From your profile, create an invite code and share it with your spouse. Once they enter it, your accounts are linked and you can share journal entries."],
  ["Is my journal private?", "Yes. Every entry is private by default. You choose whether to share an entry with your linked spouse."],
  ["Can I cancel my membership?", "Yes, anytime. You keep access until the end of your billing period."],
];

function Faq() {
  return (
    <>
      <PageHeader eyebrow="Help" title="Frequently asked questions" />
      <Accordion type="single" collapsible className="mx-auto max-w-2xl px-5">
        {faqs.map(([q, a]) => (
          <AccordionItem key={q} value={q!}>
            <AccordionTrigger className="font-serif text-xl">{q}</AccordionTrigger>
            <AccordionContent className="text-base text-muted-foreground">{a}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </>
  );
}
