import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Biblical Intimacy" },
      { name: "description", content: "How Biblical Intimacy collects, uses, and protects your information." },
      { property: "og:title", content: "Privacy Policy — Biblical Intimacy" },
      { property: "og:description", content: "How we collect, use, and protect your information." },
    ],
  }),
  component: () => (
    <>
      <PageHeader eyebrow="Legal" title="Privacy Policy" />
      <div className="prose-devotional mx-auto max-w-2xl px-5">
        <p>We collect only what we need to provide our service: your name, email, optional phone number, and your study progress and journal entries.</p>
        <p>Journal entries are private by default and are only visible to your linked spouse if you choose to share them. Your phone number is used only for discreet notifications you opt into.</p>
        <p>We never sell your data. (Placeholder — please have this policy reviewed before launch.)</p>
      </div>
    </>
  ),
});
