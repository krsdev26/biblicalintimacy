import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { mode?: "signup" } => ({ mode: s["mode"] === "signup" ? ("signup" as const) : undefined }),
  head: () => ({
    meta: [
      { title: "Sign in — Biblical Intimacy" },
      { name: "description", content: "Sign in or create your Biblical Intimacy account." },
      { property: "og:title", content: "Sign in — Biblical Intimacy" },
      { property: "og:description", content: "Sign in or create your account." },
    ],
  }),
  component: AuthPage,
});

const signupSchema = z.object({
  first_name: z.string().trim().min(1, "First name required").max(100),
  last_name: z.string().trim().min(1, "Last name required").max(100),
  email: z.string().trim().email("Valid email required").max(255),
  password: z.string().min(8, "Password must be at least 8 characters").max(72),
  phone: z.string().trim().max(30).optional(),
});

function AuthPage() {
  const { mode: initial } = Route.useSearch();
  const [mode, setMode] = useState<"signin" | "signup" | "magic" | "forgot">(initial === "signup" ? "signup" : "signin");
  const [f, setF] = useState({ first_name: "", last_name: "", email: "", password: "", phone: "" });
  const [adult, setAdult] = useState(false);
  const [busy, setBusy] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) navigate({ to: "/dashboard" });
  }, [user, navigate]);

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const p = signupSchema.safeParse(f);
        if (!p.success) { toast.error(p.error.issues[0]?.message ?? "Invalid input"); return; }
        if (!adult) { toast.error("Please confirm you are 18 or older."); return; }
        const { error } = await supabase.auth.signUp({
          email: p.data.email,
          password: p.data.password,
          options: { emailRedirectTo: window.location.origin + "/dashboard", data: { first_name: p.data.first_name, last_name: p.data.last_name, phone: p.data.phone ?? "" } },
        });
        if (error) { toast.error(error.message); return; }
        toast.success("Check your email to confirm your account.");
      } else if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email: f.email.trim(), password: f.password });
        if (error) { toast.error(error.message); return; }
      } else if (mode === "magic") {
        const { error } = await supabase.auth.signInWithOtp({ email: f.email.trim(), options: { emailRedirectTo: window.location.origin + "/dashboard", shouldCreateUser: false } });
        if (error) { toast.error(error.message); return; }
        toast.success("Check your email for a sign-in link.");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(f.email.trim(), { redirectTo: window.location.origin + "/reset-password" });
        if (error) { toast.error(error.message); return; }
        toast.success("Check your email for a reset link.");
      }
    } finally {
      setBusy(false);
    }
  };

  const titles = { signin: "Welcome back", signup: "Create your account", magic: "Email me a link", forgot: "Reset password" };

  return (
    <div className="mx-auto max-w-md px-5 py-16">
      <p className="eyebrow text-center">Biblical Intimacy</p>
      <h1 className="mt-2 text-center text-5xl text-primary">{titles[mode]}</h1>
      <form onSubmit={submit} className="mt-8 space-y-4 rounded-xl border bg-card p-7 shadow-soft">
        {mode === "signup" && (
          <div className="grid grid-cols-2 gap-3">
            <div><Label>First name</Label><Input value={f.first_name} onChange={set("first_name")} /></div>
            <div><Label>Last name</Label><Input value={f.last_name} onChange={set("last_name")} /></div>
          </div>
        )}
        <div><Label>Email</Label><Input type="email" required value={f.email} onChange={set("email")} /></div>
        {(mode === "signin" || mode === "signup") && (
          <div><Label>Password</Label><Input type="password" required value={f.password} onChange={set("password")} /></div>
        )}
        {mode === "signup" && (
          <>
            <div>
              <Label>Mobile phone (optional)</Label>
              <Input type="tel" value={f.phone} onChange={set("phone")} />
              <p className="mt-1 text-xs text-muted-foreground">Used only for discreet notifications.</p>
            </div>
            <label className="flex items-start gap-2 text-sm">
              <Checkbox checked={adult} onCheckedChange={(v) => setAdult(!!v)} className="mt-0.5" />
              I confirm I am 18 years of age or older.
            </label>
          </>
        )}
        <Button type="submit" className="w-full" size="lg" disabled={busy}>
          {mode === "signup" ? "Create account" : mode === "signin" ? "Sign in" : "Send link"}
        </Button>
        <div className="flex flex-wrap justify-between gap-2 text-sm text-muted-foreground">
          {mode !== "signin" && <button type="button" onClick={() => setMode("signin")} className="underline">Sign in with password</button>}
          {mode !== "signup" && <button type="button" onClick={() => setMode("signup")} className="underline">Create account</button>}
          {mode === "signin" && <button type="button" onClick={() => setMode("magic")} className="underline">Email me a link</button>}
          {mode === "signin" && <button type="button" onClick={() => setMode("forgot")} className="underline">Forgot password?</button>}
        </div>
      </form>
    </div>
  );
}
