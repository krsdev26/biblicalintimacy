import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Markdown, Scripture } from "@/components/site";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { audienceLabel, price } from "@/lib/format";

export const Route = createFileRoute("/studies/$slug")({
  head: () => ({
    meta: [
      { title: "Study — Biblical Intimacy" },
      { name: "description", content: "Overview, weekly outline, and a sample day from this Bible study." },
      { property: "og:title", content: "Study — Biblical Intimacy" },
      { property: "og:description", content: "Overview, weekly outline, and a sample day from this Bible study." },
    ],
  }),
  component: StudyPage,
});

function StudyPage() {
  const { slug } = Route.useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { data } = useQuery({
    queryKey: ["study", slug],
    queryFn: async () => {
      const { data: s } = await supabase.from("studies").select("*").eq("slug", slug).maybeSingle();
      if (!s) return null;
      const [{ data: weeks }, { data: outline }, { data: sample }] = await Promise.all([
        supabase.from("study_weeks").select("*").eq("study_id", s.id).order("week_number"),
        supabase.rpc("study_outline", { _study: s.id }),
        supabase.from("study_days").select("*, study_weeks!inner(study_id)").eq("is_sample", true).eq("study_weeks.study_id", s.id).limit(1),
      ]);
      return { s, weeks: weeks ?? [], outline: outline ?? [], sample: sample?.[0] };
    },
  });
  const { data: access } = useQuery({
    queryKey: ["access", data?.s.id, user?.id],
    enabled: !!user && !!data,
    queryFn: async () => (await supabase.rpc("has_study_access", { _uid: user!.id, _study: data!.s.id })).data,
  });

  if (!data) return <div className="py-32 text-center text-muted-foreground">Loading…</div>;
  const { s, weeks, outline, sample } = data;

  const buy = () => {
    if (!user) { navigate({ to: "/auth" }); return; }
    toast.info("Checkout is being set up. Please check back soon!");
  };

  return (
    <div className="mx-auto max-w-6xl px-5 pt-14">
      <div className="grid gap-12 md:grid-cols-[1fr_340px]">
        <div>
          <p className="eyebrow">{audienceLabel[s.audience]} · {s.duration_label}</p>
          <h1 className="mt-3 text-5xl leading-tight text-primary md:text-6xl">{s.title}</h1>
          {s.subtitle && <p className="mt-3 font-serif text-2xl italic text-muted-foreground">{s.subtitle}</p>}
          <p className="mt-6 text-lg leading-relaxed">{s.description}</p>

          <h2 className="mt-14 text-3xl text-primary">Week-by-week</h2>
          <div className="mt-5 space-y-3">
            {weeks.map((w) => (
              <div key={w.id} className="rounded-lg border bg-card p-5">
                <p className="eyebrow">Week {w.week_number}</p>
                <h3 className="mt-1 text-2xl">{w.title}</h3>
                <ul className="mt-2 text-sm text-muted-foreground">
                  {outline.filter((d) => d.week_id === w.id).map((d) => <li key={d.id}>{d.title} — {d.scripture_refs}</li>)}
                </ul>
              </div>
            ))}
          </div>

          {sample && (
            <>
              <h2 className="mt-14 text-3xl text-primary">Sample day</h2>
              <div className="mt-5 rounded-lg border bg-card p-7">
                <h3 className="text-2xl">{sample.title}</h3>
                <p className="mt-1 text-sm text-gold">{sample.scripture_refs}</p>
                <div className="mt-5"><Markdown>{sample.body_md}</Markdown></div>
                {sample.challenge_md && <Scripture reference="Today's challenge">{sample.challenge_md}</Scripture>}
              </div>
            </>
          )}
        </div>
        <aside className="md:sticky md:top-24 md:self-start">
          <div className="rounded-xl border bg-card p-7 shadow-soft">
            <p className="font-serif text-5xl text-primary">{price(s.price_cents)}</p>
            <p className="mt-1 text-sm text-muted-foreground">{s.included_in_membership ? "Also included with membership" : "One-time purchase"}</p>
            {access ? (
              <Button asChild className="mt-6 w-full" size="lg"><Link to="/read/$slug" params={{ slug: s.slug }}>Open study</Link></Button>
            ) : (
              <>
                <Button className="mt-6 w-full" size="lg" onClick={buy}>Buy this study</Button>
                <Button asChild variant="outline" className="mt-2 w-full"><Link to="/pricing">Or become a member</Link></Button>
              </>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
