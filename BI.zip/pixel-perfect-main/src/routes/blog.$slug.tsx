import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Markdown } from "@/components/site";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { date } from "@/lib/format";

export const Route = createFileRoute("/blog/$slug")({
  head: () => ({
    meta: [
      { title: "Article — Biblical Intimacy" },
      { name: "description", content: "Biblical teaching on marriage and intimacy." },
      { property: "og:title", content: "Article — Biblical Intimacy" },
      { property: "og:description", content: "Biblical teaching on marriage and intimacy." },
      { property: "og:type", content: "article" },
    ],
  }),
  component: Post,
});

function Post() {
  const { slug } = Route.useParams();
  const { user } = useAuth();
  const { data, isLoading } = useQuery({
    queryKey: ["post", slug, user?.id],
    queryFn: async () => (await supabase.rpc("get_post", { _slug: slug })).data?.[0] ?? null,
  });
  if (isLoading) return <div className="py-32 text-center text-muted-foreground">Loading…</div>;
  if (!data) return <div className="py-32 text-center">Post not found. <Link to="/blog" className="underline">Back to blog</Link></div>;
  return (
    <article className="mx-auto max-w-2xl px-5 pt-16">
      <p className="eyebrow">{data.category}</p>
      <h1 className="mt-3 text-5xl leading-tight text-primary">{data.title}</h1>
      <p className="mt-3 text-sm text-muted-foreground">{date(data.published_at!)}</p>
      <div className="relative mt-10">
        <Markdown>{data.body_md + (data.locked ? "…" : "")}</Markdown>
        {data.locked && (
          <>
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-background to-transparent" />
            <div className="relative -mt-6 rounded-xl border bg-card/80 p-8 text-center shadow-soft backdrop-blur">
              <Lock className="mx-auto h-6 w-6 text-gold" />
              <h2 className="mt-3 text-3xl text-primary">Continue reading as a member</h2>
              <p className="mt-2 text-muted-foreground">This article is part of our members-only library.</p>
              <div className="mt-6 flex justify-center gap-3">
                <Button asChild><Link to="/pricing">View membership</Link></Button>
                {!user && <Button asChild variant="outline"><Link to="/auth">Sign in</Link></Button>}
              </div>
            </div>
          </>
        )}
      </div>
    </article>
  );
}
