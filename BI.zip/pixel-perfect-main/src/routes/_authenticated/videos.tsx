import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PageHeader } from "@/components/site";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/videos")({
  head: () => ({ meta: [{ title: "Video Library — Biblical Intimacy" }, { name: "description", content: "Recorded teaching sessions." }] }),
  component: Videos,
});

function Videos() {
  const { isMember } = useAuth();
  const { data } = useQuery({ queryKey: ["videos"], queryFn: async () => (await supabase.from("videos").select("*").order("published_at", { ascending: false })).data ?? [] });
  return (
    <>
      <PageHeader eyebrow="Library" title="Recorded teaching">
        {!isMember && <span>Members see the full library. <Link to="/pricing" className="underline">Become a member</Link>.</span>}
      </PageHeader>
      <div className="mx-auto grid max-w-6xl gap-6 px-5 md:grid-cols-2">
        {data?.map((v) => (
          <div key={v.id} className="overflow-hidden rounded-xl border bg-card shadow-soft">
            <div className="aspect-video"><iframe src={v.embed_url} title={v.title} className="h-full w-full" allowFullScreen /></div>
            <div className="p-5"><h2 className="text-2xl text-primary">{v.title}</h2><p className="text-sm text-muted-foreground">{v.description}</p></div>
          </div>
        ))}
      </div>
    </>
  );
}
