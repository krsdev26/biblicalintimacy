import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { date } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Biblical Intimacy" }, { name: "description", content: "Your studies, events, and videos." }] }),
  component: Dashboard,
});

function Dashboard() {
  const { user } = Route.useRouteContext();
  const { data } = useQuery({
    queryKey: ["dashboard", user.id],
    queryFn: async () => {
      const [profile, studies, progress, regs, videos] = await Promise.all([
        supabase.from("profiles").select("*").eq("id", user.id).single(),
        supabase.from("studies").select("id, slug, title").eq("status", "published").order("sort"),
        supabase.from("study_progress").select("study_day_id, completed_at").order("completed_at", { ascending: false }),
        supabase.from("event_registrations").select("events(*)").eq("user_id", user.id),
        supabase.from("videos").select("*").order("published_at", { ascending: false }).limit(3),
      ]);
      const my: { id: string; slug: string; title: string; total: number; done: number }[] = [];
      for (const s of studies.data ?? []) {
        const { data: ok } = await supabase.rpc("has_study_access", { _uid: user.id, _study: s.id });
        if (!ok) continue;
        const { data: outline } = await supabase.rpc("study_outline", { _study: s.id });
        const ids = new Set(outline?.map((d) => d.id));
        my.push({ ...s, total: ids.size, done: (progress.data ?? []).filter((p) => ids.has(p.study_day_id)).length });
      }
      let spouse = null;
      if (profile.data?.couple_id) {
        spouse = (await supabase.from("profiles").select("first_name").eq("couple_id", profile.data.couple_id).neq("id", user.id).maybeSingle()).data;
      }
      const lastDay = progress.data?.[0]?.study_day_id;
      let resume = my.find((s) => s.done < s.total) ?? my[0];
      if (lastDay) {
        for (const s of my) {
          const { data: o } = await supabase.rpc("study_outline", { _study: s.id });
          if (o?.some((d) => d.id === lastDay)) resume = s;
        }
      }
      return { profile: profile.data, my, resume, events: (regs.data ?? []).map((r) => r.events).filter(Boolean), videos: videos.data ?? [], spouse };
    },
  });

  if (!data) return <div className="py-32 text-center text-muted-foreground">Loading…</div>;
  return (
    <div className="mx-auto max-w-6xl px-5 py-12">
      <p className="eyebrow">Dashboard</p>
      <h1 className="mt-2 text-5xl text-primary">Welcome, {data.profile?.first_name || "friend"}</h1>

      <div className="mt-10 grid gap-6 md:grid-cols-3">
        <div className="rounded-xl bg-forest p-7 text-primary-foreground md:col-span-2">
          <p className="eyebrow">Continue where you left off</p>
          {data.resume ? (
            <>
              <h2 className="mt-3 text-3xl">{data.resume.title}</h2>
              <Progress value={(data.resume.done / Math.max(1, data.resume.total)) * 100} className="mt-4 bg-primary-foreground/20" />
              <p className="mt-2 text-sm text-primary-foreground/70">{data.resume.done} of {data.resume.total} days complete</p>
              <Button asChild variant="gold" className="mt-5"><Link to="/read/$slug" params={{ slug: data.resume.slug }}>Continue studying</Link></Button>
            </>
          ) : (
            <>
              <h2 className="mt-3 text-3xl">Begin your first study</h2>
              <Button asChild variant="gold" className="mt-5"><Link to="/studies">Browse studies</Link></Button>
            </>
          )}
        </div>
        <div className="rounded-xl border bg-card p-7 shadow-soft">
          <Heart className="h-6 w-6 text-gold" />
          {data.spouse ? (
            <><h2 className="mt-3 text-2xl text-primary">Linked with {data.spouse.first_name}</h2><p className="mt-1 text-sm text-muted-foreground">You can share journal entries with each other.</p></>
          ) : (
            <><h2 className="mt-3 text-2xl text-primary">Invite your spouse</h2><p className="mt-1 text-sm text-muted-foreground">Link accounts to study and journal together.</p>
              <Button asChild variant="outline" className="mt-4"><Link to="/profile">Link accounts</Link></Button></>
          )}
        </div>
      </div>

      <h2 className="mt-14 text-3xl text-primary">My studies</h2>
      <div className="mt-5 grid gap-4 md:grid-cols-3">
        {data.my.length === 0 && <p className="text-muted-foreground">No studies yet. <Link to="/studies" className="underline">Browse the catalog</Link>.</p>}
        {data.my.map((s) => (
          <Link key={s.id} to="/read/$slug" params={{ slug: s.slug }} className="rounded-lg border bg-card p-5 shadow-soft">
            <h3 className="text-xl">{s.title}</h3>
            <Progress value={(s.done / Math.max(1, s.total)) * 100} className="mt-3" />
            <p className="mt-1 text-xs text-muted-foreground">{s.done}/{s.total} days</p>
          </Link>
        ))}
      </div>

      <div className="mt-14 grid gap-10 md:grid-cols-2">
        <div>
          <h2 className="text-3xl text-primary">My upcoming events</h2>
          <div className="mt-4 space-y-3">
            {data.events.length === 0 && <p className="text-muted-foreground">None yet. <Link to="/events" className="underline">See intensives</Link>.</p>}
            {data.events.map((e) => e && <div key={e.id} className="rounded-lg border bg-card p-4"><p className="font-medium">{e.title}</p><p className="text-sm text-muted-foreground">{date(e.starts_at)} · {e.location}</p></div>)}
          </div>
        </div>
        <div>
          <div className="flex items-end justify-between"><h2 className="text-3xl text-primary">Latest videos</h2><Link to="/videos" className="text-sm underline">All videos</Link></div>
          <div className="mt-4 space-y-3">
            {data.videos.map((v) => <Link key={v.id} to="/videos" className="block rounded-lg border bg-card p-4"><p className="font-medium">{v.title}</p><p className="text-sm text-muted-foreground">{v.description}</p></Link>)}
          </div>
        </div>
      </div>
    </div>
  );
}
