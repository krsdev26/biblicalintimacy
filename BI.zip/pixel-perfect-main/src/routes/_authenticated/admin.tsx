import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { CalendarDays, FileText, GraduationCap, Mail, Users, Video } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/site";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [
    { title: "Admin — Biblical Intimacy" }, { name: "description", content: "Manage Biblical Intimacy content and view activity." },
    { property: "og:title", content: "Admin — Biblical Intimacy" }, { property: "og:description", content: "Manage content and view activity." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }), component: AdminPage,
});

function AdminPage() {
  const { isAdmin, loading } = useAuth();
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["admin"], enabled: isAdmin, queryFn: async () => {
    const [stats, studies, posts, events, videos, messages] = await Promise.all([
      supabase.rpc("admin_stats"), supabase.from("studies").select("id,title,status,slug").order("sort"), supabase.from("posts").select("id,title,status,slug").order("published_at", { ascending: false }), supabase.from("events").select("id,title,starts_at").order("starts_at"), supabase.from("videos").select("id,title,access").order("published_at", { ascending: false }), supabase.from("contact_messages").select("id,name,email,message,created_at").order("created_at", { ascending: false }).limit(10),
    ]);
    return { stats: stats.data as { members?: number; subscribers?: number; registrations?: number; signups?: number } | null, studies: studies.data ?? [], posts: posts.data ?? [], events: events.data ?? [], videos: videos.data ?? [], messages: messages.data ?? [] };
  }});
  if (loading) return <div className="py-32 text-center text-muted-foreground">Checking access…</div>;
  if (!isAdmin) return <div className="mx-auto max-w-lg px-5 py-24 text-center"><h1 className="text-4xl text-primary">Admin access required</h1><Button asChild className="mt-6"><Link to="/dashboard">Return to dashboard</Link></Button></div>;
  const publish = async (table: "studies" | "posts", id: string, status: string) => { const { error } = await supabase.from(table).update({ status: status === "published" ? "draft" : "published" }).eq("id", id); if (error) return toast.error("Status could not be changed."); queryClient.invalidateQueries({ queryKey: ["admin"] }); };
  const stats = query.data?.stats;
  const statItems = [{ label: "Members", value: stats?.members ?? 0, icon: Users }, { label: "Subscribers", value: stats?.subscribers ?? 0, icon: GraduationCap }, { label: "Registrations", value: stats?.registrations ?? 0, icon: CalendarDays }, { label: "Email signups", value: stats?.signups ?? 0, icon: Mail }];
  return <><PageHeader eyebrow="Administration" title="Content & activity"><p>A concise view of your audience and published resources.</p></PageHeader><div className="mx-auto max-w-6xl px-5">
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{statItems.map(({ label, value, icon: Icon }) => <div key={label} className="rounded-lg border bg-card p-5"><Icon className="h-5 w-5 text-gold"/><p className="mt-3 text-3xl font-semibold text-primary">{value}</p><p className="text-sm text-muted-foreground">{label}</p></div>)}</div>
    <div className="mt-10 grid gap-8 lg:grid-cols-2"><AdminList title="Studies" icon={GraduationCap} rows={query.data?.studies ?? []} action={publish}/><AdminList title="Posts" icon={FileText} rows={query.data?.posts ?? []} action={publish}/><SimpleList title="Events" icon={CalendarDays} rows={(query.data?.events ?? []).map((e) => ({ id: e.id, title: e.title, note: new Date(e.starts_at).toLocaleDateString() }))}/><SimpleList title="Videos" icon={Video} rows={(query.data?.videos ?? []).map((v) => ({ id: v.id, title: v.title, note: v.access }))}/></div>
    <section className="mt-8"><h2 className="text-3xl text-primary">Recent messages</h2><div className="mt-4 divide-y rounded-lg border bg-card">{query.data?.messages.map((m) => <div key={m.id} className="p-5"><div className="flex flex-wrap justify-between gap-2"><p className="font-medium">{m.name} · {m.email}</p><p className="text-xs text-muted-foreground">{new Date(m.created_at).toLocaleDateString()}</p></div><p className="mt-2 text-sm text-muted-foreground">{m.message}</p></div>)}{!query.data?.messages.length && <p className="p-5 text-muted-foreground">No messages yet.</p>}</div></section>
  </div></>;
}

function AdminList({ title, icon: Icon, rows, action }: { title: string; icon: typeof GraduationCap; rows: { id: string; title: string; status: string }[]; action: (table: "studies" | "posts", id: string, status: string) => void }) {
  const table = title === "Studies" ? "studies" : "posts";
  return <section><h2 className="flex items-center gap-2 text-3xl text-primary"><Icon className="h-6 w-6 text-gold"/>{title}</h2><div className="mt-4 divide-y rounded-lg border bg-card">{rows.map((row) => <div key={row.id} className="flex items-center justify-between gap-3 p-4"><div><p className="font-medium">{row.title}</p><p className="text-xs capitalize text-muted-foreground">{row.status}</p></div><Button size="sm" variant="outline" onClick={() => action(table, row.id, row.status)}>{row.status === "published" ? "Unpublish" : "Publish"}</Button></div>)}{!rows.length && <p className="p-4 text-muted-foreground">Nothing here yet.</p>}</div></section>;
}
function SimpleList({ title, icon: Icon, rows }: { title: string; icon: typeof Video; rows: { id: string; title: string; note: string }[] }) { return <section><h2 className="flex items-center gap-2 text-3xl text-primary"><Icon className="h-6 w-6 text-gold"/>{title}</h2><div className="mt-4 divide-y rounded-lg border bg-card">{rows.map((row) => <div key={row.id} className="p-4"><p className="font-medium">{row.title}</p><p className="text-xs capitalize text-muted-foreground">{row.note}</p></div>)}{!rows.length && <p className="p-4 text-muted-foreground">Nothing here yet.</p>}</div></section>; }