import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Copy, Heart, Link2, Unlink } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/site";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({ meta: [
    { title: "Profile — Biblical Intimacy" }, { name: "description", content: "Manage your profile and spouse connection." },
    { property: "og:title", content: "Profile — Biblical Intimacy" }, { property: "og:description", content: "Manage your profile and spouse connection." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user } = Route.useRouteContext();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ first_name: "", last_name: "", phone: "", notify_email: true, notify_sms: false });
  const [inviteCode, setInviteCode] = useState("");
  const query = useQuery({ queryKey: ["profile", user.id], queryFn: async () => {
    const { data: profile, error } = await supabase.from("profiles").select("*").eq("id", user.id).single();
    if (error) throw error;
    const spouse = profile.couple_id ? (await supabase.from("profiles").select("first_name,last_name").eq("couple_id", profile.couple_id).neq("id", user.id).maybeSingle()).data : null;
    const invite = !profile.couple_id ? (await supabase.from("couple_invites").select("code").eq("inviter_id", user.id).is("used_at", null).order("created_at", { ascending: false }).limit(1).maybeSingle()).data : null;
    return { profile, spouse, invite };
  }});
  useEffect(() => { if (query.data?.profile) setForm({ first_name: query.data.profile.first_name, last_name: query.data.profile.last_name, phone: query.data.profile.phone ?? "", notify_email: query.data.profile.notify_email, notify_sms: query.data.profile.notify_sms }); }, [query.data?.profile]);
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["profile", user.id] });
  const save = async () => { const { error } = await supabase.from("profiles").update({ ...form, phone: form.phone || null }).eq("id", user.id); if (error) return toast.error("Your profile could not be saved."); toast.success("Profile saved."); refresh(); };
  const createInvite = async () => { const { data, error } = await supabase.from("couple_invites").insert({ inviter_id: user.id }).select("code").single(); if (error) return toast.error("An invite could not be created."); await refresh(); setInviteCode(data.code); };
  const acceptInvite = async () => { if (!inviteCode.trim()) return; const { error } = await supabase.rpc("accept_couple_invite", { _code: inviteCode.trim().toLowerCase() }); if (error) return toast.error(error.message); toast.success("Your accounts are now linked."); setInviteCode(""); refresh(); };
  const unlink = async () => { const { error } = await supabase.rpc("unlink_couple"); if (error) return toast.error("The connection could not be removed."); toast.success("Accounts unlinked."); refresh(); };
  const code = query.data?.invite?.code;

  return <><PageHeader eyebrow="Your account" title="Profile & spouse"><p>Keep your details current and choose whether to study together.</p></PageHeader><div className="mx-auto grid max-w-5xl gap-8 px-5 md:grid-cols-2">
    <section className="rounded-lg border bg-card p-6 shadow-soft"><h2 className="text-2xl text-primary">Personal details</h2><div className="mt-5 grid gap-4"><div className="grid grid-cols-2 gap-3"><div><Label>First name</Label><Input value={form.first_name} onChange={(e) => setForm({ ...form, first_name: e.target.value })}/></div><div><Label>Last name</Label><Input value={form.last_name} onChange={(e) => setForm({ ...form, last_name: e.target.value })}/></div></div><div><Label>Email</Label><Input value={user.email ?? ""} disabled/></div><div><Label>Mobile phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })}/></div><label className="flex items-center gap-2 text-sm"><Checkbox checked={form.notify_email} onCheckedChange={(v) => setForm({ ...form, notify_email: !!v })}/> Email notifications</label><label className="flex items-center gap-2 text-sm"><Checkbox checked={form.notify_sms} onCheckedChange={(v) => setForm({ ...form, notify_sms: !!v })}/> Text notifications</label><Button onClick={save}>Save profile</Button></div></section>
    <section className="rounded-lg border bg-card p-6 shadow-soft"><Heart className="h-7 w-7 text-gold"/><h2 className="mt-3 text-2xl text-primary">Spouse connection</h2>{query.data?.spouse ? <div className="mt-5"><p>You’re linked with <strong>{query.data.spouse.first_name} {query.data.spouse.last_name}</strong>.</p><p className="mt-2 text-sm text-muted-foreground">You can share selected reflections with each other.</p><Button className="mt-5" variant="outline" onClick={unlink}><Unlink/> Unlink accounts</Button></div> : <div className="mt-5 space-y-6"><div><p className="text-sm text-muted-foreground">Send this private code to your spouse:</p>{code ? <div className="mt-2 flex gap-2"><Input readOnly value={code} className="font-mono text-lg uppercase"/><Button size="icon" variant="outline" aria-label="Copy invite code" onClick={() => { navigator.clipboard.writeText(code); toast.success("Invite code copied."); }}><Copy/></Button></div> : <Button className="mt-3" variant="outline" onClick={createInvite}>Create invite code</Button>}</div><div className="border-t pt-5"><Label>I received a code</Label><div className="mt-2 flex gap-2"><Input value={inviteCode} onChange={(e) => setInviteCode(e.target.value)} placeholder="Enter code"/><Button onClick={acceptInvite}><Link2/> Link</Button></div></div></div>}</section>
  </div></>;
}