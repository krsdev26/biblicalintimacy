import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, ArrowRight, Check, LockKeyhole, Save } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Markdown, Scripture } from "@/components/site";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/read/$slug")({
  head: () => ({ meta: [
    { title: "Study Reader — Biblical Intimacy" },
    { name: "description", content: "Read your Bible study, save reflections, and track your progress." },
    { property: "og:title", content: "Study Reader — Biblical Intimacy" },
    { property: "og:description", content: "Read your Bible study and track your progress." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: StudyReader,
});

function StudyReader() {
  const { slug } = Route.useParams();
  const { user } = Route.useRouteContext();
  const queryClient = useQueryClient();
  const [selectedId, setSelectedId] = useState<string>();
  const [journal, setJournal] = useState("");
  const [visibility, setVisibility] = useState<"private" | "shared_with_spouse">("private");
  const [saving, setSaving] = useState(false);
  const query = useQuery({
    queryKey: ["reader", slug, user.id],
    queryFn: async () => {
      const { data: study, error } = await supabase.from("studies").select("*").eq("slug", slug).maybeSingle();
      if (error) throw error;
      if (!study) return null;
      const { data: allowed } = await supabase.rpc("has_study_access", { _uid: user.id, _study: study.id });
      if (!allowed) return { study, allowed: false as const, weeks: [], days: [], progress: [], journals: [] };
      const { data: weeks } = await supabase.from("study_weeks").select("*").eq("study_id", study.id).order("week_number");
      const weekIds = (weeks ?? []).map((week) => week.id);
      const [{ data: days }, { data: progress }, { data: journals }] = await Promise.all([
        weekIds.length ? supabase.from("study_days").select("*").in("week_id", weekIds).order("day_number") : Promise.resolve({ data: [] }),
        supabase.from("study_progress").select("*").eq("user_id", user.id),
        supabase.from("journal_entries").select("*").eq("user_id", user.id),
      ]);
      const orderedDays = (weeks ?? []).flatMap((week) => (days ?? []).filter((day) => day.week_id === week.id));
      return { study, allowed: true as const, weeks: weeks ?? [], days: orderedDays, progress: progress ?? [], journals: journals ?? [] };
    },
  });
  const data = query.data;
  const activeId = selectedId ?? data?.days.find((day) => !data.progress.some((p) => p.study_day_id === day.id))?.id ?? data?.days[0]?.id;
  const active = data?.days.find((day) => day.id === activeId);
  const activeIndex = data?.days.findIndex((day) => day.id === activeId) ?? -1;
  const entry = data?.journals.find((item) => item.study_day_id === activeId);
  const completed = !!data?.progress.some((item) => item.study_day_id === activeId);
  const questions = useMemo(() => Array.isArray(active?.reflection_questions) ? active.reflection_questions.filter((q): q is string => typeof q === "string") : [], [active]);

  useEffect(() => {
    setJournal(entry?.body ?? "");
    setVisibility(entry?.visibility === "shared_with_spouse" ? "shared_with_spouse" : "private");
  }, [entry?.id, activeId]);

  if (query.isLoading) return <div className="py-32 text-center text-muted-foreground">Opening your study…</div>;
  if (!data) return <div className="py-32 text-center"><h1 className="text-4xl text-primary">Study not found</h1><Button asChild className="mt-6"><Link to="/studies">Browse studies</Link></Button></div>;
  if (!data.allowed) return <div className="mx-auto max-w-xl px-5 py-24 text-center"><LockKeyhole className="mx-auto h-8 w-8 text-gold"/><h1 className="mt-4 text-4xl text-primary">This study isn’t in your library</h1><Button asChild className="mt-6"><Link to="/studies/$slug" params={{ slug }}>View access options</Link></Button></div>;
  if (!active) return <div className="py-32 text-center text-muted-foreground">This study has no reading days yet.</div>;

  const toggleComplete = async () => {
    const result = completed
      ? await supabase.from("study_progress").delete().eq("user_id", user.id).eq("study_day_id", active.id)
      : await supabase.from("study_progress").insert({ user_id: user.id, study_day_id: active.id });
    if (result.error) return toast.error("Progress could not be updated.");
    await queryClient.invalidateQueries({ queryKey: ["reader", slug, user.id] });
  };
  const saveJournal = async () => {
    setSaving(true);
    const values = { body: journal.trim(), visibility, study_day_id: active.id, user_id: user.id };
    const result = entry
      ? await supabase.from("journal_entries").update(values).eq("id", entry.id)
      : await supabase.from("journal_entries").insert(values);
    setSaving(false);
    if (result.error) return toast.error("Your reflection could not be saved.");
    toast.success("Reflection saved.");
    await queryClient.invalidateQueries({ queryKey: ["reader", slug, user.id] });
  };

  return <div className="mx-auto grid max-w-7xl gap-8 px-5 py-10 lg:grid-cols-[260px_minmax(0,1fr)]">
    <aside className="lg:sticky lg:top-24 lg:self-start">
      <Link to="/dashboard" className="flex items-center gap-2 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4"/> Dashboard</Link>
      <h1 className="mt-5 text-3xl text-primary">{data.study.title}</h1>
      <div className="mt-6 max-h-[60vh] space-y-5 overflow-y-auto pr-2">
        {data.weeks.map((week) => <div key={week.id}><p className="eyebrow">Week {week.week_number}</p><p className="mt-1 font-medium">{week.title}</p><div className="mt-2 space-y-1">{data.days.filter((day) => day.week_id === week.id).map((day) => <Button key={day.id} variant={day.id === active.id ? "secondary" : "ghost"} className="h-auto w-full justify-start whitespace-normal py-2 text-left" onClick={() => setSelectedId(day.id)}>{data.progress.some((p) => p.study_day_id === day.id) && <Check className="text-gold"/>}{day.title}</Button>)}</div></div>)}
      </div>
    </aside>
    <article className="min-w-0">
      <p className="eyebrow">Day {active.day_number}</p>
      <h2 className="mt-2 text-4xl text-primary md:text-5xl">{active.title}</h2>
      {active.scripture_refs && <p className="mt-3 text-gold">{active.scripture_refs}</p>}
      <div className="mt-8"><Markdown>{active.body_md}</Markdown></div>
      {active.challenge_md && <Scripture reference="Today’s practice">{active.challenge_md}</Scripture>}
      {questions.length > 0 && <section className="mt-10 border-t pt-8"><h3 className="text-2xl text-primary">Reflect together</h3><ol className="mt-4 list-decimal space-y-3 pl-5">{questions.map((question) => <li key={question}>{question}</li>)}</ol></section>}
      <section className="mt-10 border-t pt-8"><div className="flex flex-wrap items-center justify-between gap-3"><div><h3 className="text-2xl text-primary">Your reflection</h3><p className="text-sm text-muted-foreground">Private unless you choose to share it with your linked spouse.</p></div><label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={visibility === "shared_with_spouse"} onChange={(e) => setVisibility(e.target.checked ? "shared_with_spouse" : "private")} /> Share with spouse</label></div><Textarea className="mt-4 min-h-40 bg-card" value={journal} onChange={(e) => setJournal(e.target.value)} placeholder="Write what stood out to you…"/><Button className="mt-3" variant="outline" onClick={saveJournal} disabled={saving || !journal.trim()}><Save/> Save reflection</Button></section>
      <div className="mt-12 flex flex-wrap items-center justify-between gap-3 border-t pt-6"><Button variant="outline" disabled={activeIndex <= 0} onClick={() => setSelectedId(data.days[activeIndex - 1]?.id)}><ArrowLeft/> Previous</Button><Button variant={completed ? "secondary" : "default"} onClick={toggleComplete}>{completed ? "Completed" : "Mark complete"}<Check/></Button><Button variant="outline" disabled={activeIndex >= data.days.length - 1} onClick={() => setSelectedId(data.days[activeIndex + 1]?.id)}>Next <ArrowRight/></Button></div>
    </article>
  </div>;
}