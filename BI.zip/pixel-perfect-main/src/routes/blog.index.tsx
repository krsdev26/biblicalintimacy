import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Lock } from "lucide-react";
import { PageHeader } from "@/components/site";
import { supabase } from "@/integrations/supabase/client";
import { date } from "@/lib/format";

export const Route = createFileRoute("/blog/")({
  head: () => ({
    meta: [
      { title: "Blog — Biblical Intimacy" },
      { name: "description", content: "Articles on marriage, intimacy, and spiritual growth from a biblical perspective." },
      { property: "og:title", content: "Blog — Biblical Intimacy" },
      { property: "og:description", content: "Articles on marriage, intimacy, and spiritual growth from a biblical perspective." },
    ],
  }),
  component: Blog,
});

function Blog() {
  const { data } = useQuery({ queryKey: ["posts"], queryFn: async () => (await supabase.rpc("list_posts")).data ?? [] });
  return (
    <>
      <PageHeader eyebrow="The Blog" title="Writing for your marriage" />
      <div className="mx-auto grid max-w-5xl gap-6 px-5 md:grid-cols-2">
        {data?.map((p) => (
          <Link key={p.id} to="/blog/$slug" params={{ slug: p.slug }} className="rounded-lg border bg-card p-7 shadow-soft transition hover:-translate-y-0.5">
            <p className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground">
              {p.category} · {date(p.published_at!)}
              {p.access === "members" && <span className="flex items-center gap-1 text-gold"><Lock className="h-3 w-3" /> Members</span>}
            </p>
            <h2 className="mt-3 text-3xl text-primary">{p.title}</h2>
            <p className="mt-2 text-muted-foreground">{p.excerpt}</p>
          </Link>
        ))}
      </div>
    </>
  );
}
