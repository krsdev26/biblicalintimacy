import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Service — Biblical Intimacy" },
      { name: "description", content: "The terms for using Biblical Intimacy studies, membership, and events." },
      { property: "og:title", content: "Terms of Service — Biblical Intimacy" },
      { property: "og:description", content: "The terms for using Biblical Intimacy." },
    ],
  }),
  component: () => (
    <>
      <PageHeader eyebrow="Legal" title="Terms of Service" />
      <div className="prose-devotional mx-auto max-w-2xl px-5">
        <p>This site is intended for married adults aged 18 and over. By creating an account you confirm you meet this requirement.</p>
        <p>Study content is licensed for personal and small-group use and may not be redistributed. Memberships renew until cancelled.</p>
        <p>(Placeholder — please have these terms reviewed before launch.)</p>
      </div>
    </>
  ),
});
