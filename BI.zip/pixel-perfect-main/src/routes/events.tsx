import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/site";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { price } from "@/lib/format";

export const Route = createFileRoute("/events")({
  head: () => ({
    meta: [
      { title: "Marriage Intensives — Biblical Intimacy" },
      { name: "description", content: "Upcoming live marriage intensives, retreats, and online Q&A events." },
      { property: "og:title", content: "Marriage Intensives — Biblical Intimacy" },
      { property: "og:description", content: "Upcoming live marriage intensives, retreats, and online Q&A events." },
    ],
  }),
  component: Events,
});

function Events() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { data } = useQuery({ queryKey: ["events"], queryFn: async () => (await supabase.from("events").select("*").gte("starts_at", new Date().toISOString()).order("starts_at")).data ?? [] });
  const { data: regs } = useQuery({ queryKey: ["my-regs", user?.id], enabled: !!user, queryFn: async () => (await supabase.from("event_registrations").select("event_id").eq("user_id", user!.id)).data ?? [] });
  const registered = new Set(regs?.map((r) => r.event_id));

  const register = async (id: string) => {
    if (!user) { navigate({ to: "/auth" }); return; }
    const { error } = registered.has(id)
      ? await supabase.from("event_registrations").delete().eq("event_id", id).eq("user_id", user.id)
      : await supabase.from("event_registrations").insert({ event_id: id });
    if (error) { toast.error(error.message); return; }
    toast.success(registered.has(id) ? "Registration cancelled" : "You're registered!");
    qc.invalidateQueries({ queryKey: ["my-regs"] });
  };

  return (
    <>
      <PageHeader eyebrow="Live" title="Marriage Intensives">Teaching, worship, and guided time together — in person and online.</PageHeader>
      <div className="mx-auto max-w-4xl space-y-5 px-5">
        {data?.map((e) => {
          const d = new Date(e.starts_at);
          return (
            <div key={e.id} className="flex flex-col gap-6 rounded-xl border bg-card p-7 shadow-soft sm:flex-row sm:items-center">
              <div className="w-20 shrink-0 text-center">
                <p className="text-xs uppercase tracking-widest text-gold">{d.toLocaleString("en-US", { month: "short" })}</p>
                <p className="font-serif text-5xl text-primary">{d.getDate()}</p>
                <p className="text-xs text-muted-foreground">{d.getFullYear()}</p>
              </div>
              <div className="flex-1">
                <h2 className="text-3xl text-primary">{e.title}</h2>
                <p className="mt-1 text-sm text-muted-foreground">{e.location} · {d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })} · {price(e.price_cents)}</p>
                <p className="mt-3">{e.description}</p>
              </div>
              <Button variant={registered.has(e.id) ? "outline" : "default"} onClick={() => register(e.id)}>
                {!user ? "Sign in to register" : registered.has(e.id) ? "Registered ✓" : "Register"}
              </Button>
            </div>
          );
        })}
      </div>
    </>
  );
}
