import { createFileRoute, Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/site";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — Biblical Intimacy" },
      { name: "description", content: "Free articles, individual studies, or a full membership for your marriage." },
      { property: "og:title", content: "Pricing — Biblical Intimacy" },
      { property: "og:description", content: "Free articles, individual studies, or a full membership for your marriage." },
    ],
  }),
  component: Pricing,
});

const tiers = [
  { name: "Free", price: "$0", note: "forever", features: ["Free blog articles", "Sample study days", "Weekly email encouragement"], cta: "Create account" },
  { name: "Membership", price: "$12", note: "per month, per couple", features: ["Every included Bible study", "Full video library", "Members-only articles", "Link with your spouse", "Shared journaling"], cta: "Become a member", featured: true },
  { name: "Single study", price: "from $19", note: "one-time", features: ["Lifetime access to one study", "Downloadable PDF", "Progress tracking"], cta: "Browse studies" },
];

function Pricing() {
  const { user } = useAuth();
  return (
    <>
      <PageHeader eyebrow="Pricing" title="Simple, couple-friendly pricing" />
      <div className="mx-auto grid max-w-5xl gap-6 px-5 md:grid-cols-3">
        {tiers.map((t) => (
          <div key={t.name} className={`flex flex-col rounded-xl border p-8 shadow-soft ${t.featured ? "bg-forest text-primary-foreground" : "bg-card"}`}>
            <p className="eyebrow">{t.name}</p>
            <p className="mt-4 font-serif text-5xl">{t.price}</p>
            <p className={`text-sm ${t.featured ? "text-primary-foreground/70" : "text-muted-foreground"}`}>{t.note}</p>
            <ul className="mt-6 flex-1 space-y-2 text-sm">
              {t.features.map((f) => <li key={f} className="flex gap-2"><Check className="h-4 w-4 text-gold" />{f}</li>)}
            </ul>
            {t.name === "Membership" ? (
              <Button variant="gold" className="mt-8" onClick={() => toast.info(user ? "Checkout is being set up. Please check back soon!" : "Please create an account first.")}>{t.cta}</Button>
            ) : (
              <Button asChild variant="outline" className="mt-8"><Link to={t.name === "Free" ? "/auth" : "/studies"}>{t.cta}</Link></Button>
            )}
          </div>
        ))}
      </div>
    </>
  );
}
