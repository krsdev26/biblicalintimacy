import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PageHeader, StudyCard } from "@/components/site";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/studies/")({
  head: () => ({
    meta: [
      { title: "Bible Studies — Biblical Intimacy" },
      { name: "description", content: "Digital Bible studies for couples, husbands, and wives on intimacy, purity, and the names of God." },
      { property: "og:title", content: "Bible Studies — Biblical Intimacy" },
      { property: "og:description", content: "Digital Bible studies for couples, husbands, and wives." },
    ],
  }),
  component: Studies,
});

function Studies() {
  const { data } = useQuery({ queryKey: ["studies"], queryFn: async () => (await supabase.from("studies").select("*").eq("status", "published").order("sort")).data ?? [] });
  return (
    <>
      <PageHeader eyebrow="Digital Bible Studies" title="Studies for your marriage">
        Day-by-day readings, reflection questions, and challenges — for couples, husbands, and wives.
      </PageHeader>
      <div className="mx-auto grid max-w-6xl gap-6 px-5 sm:grid-cols-2 lg:grid-cols-3">
        {data?.map((s) => <StudyCard key={s.id} s={s} />)}
      </div>
    </>
  );
}
