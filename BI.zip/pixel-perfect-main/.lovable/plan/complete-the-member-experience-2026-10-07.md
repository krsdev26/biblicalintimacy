# Complete the member experience

## What I’ll build
- Repair the current broken navigation by adding the missing study reader, profile, and admin pages.
- Add the study-reading flow with day navigation, progress completion, and private/shared journal entries.
- Add profile editing and spouse-linking controls using the account fields already supported by the database.
- Add an admin workspace for managing the existing studies, events, posts, and videos.
- Update the welcome screen with two unmistakable choices: proceed to the site or leave.
- Verify sign-in, member navigation, and the main reading flow in the live preview.

## Technical details
- Keep every member page inside the existing authenticated route layout.
- Use the current Lovable Cloud tables, access checks, and generated data types; no schema expansion unless an existing feature cannot work without it.
- Add unique page metadata for every new route and preserve the existing visual system.
