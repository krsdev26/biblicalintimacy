
create type public.app_role as enum ('member','admin');
create type public.gender as enum ('husband','wife');
create type public.study_audience as enum ('couples','husbands','wives','everyone');

create table public.couples (id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(), status text not null default 'active' check (status in ('active','unlinked')));
grant select, update on public.couples to authenticated; grant all on public.couples to service_role;
alter table public.couples enable row level security;

create table public.profiles (
  id uuid primary key, first_name text not null default '', last_name text not null default '', avatar_url text, phone text,
  phone_verified boolean not null default false, gender public.gender, couple_id uuid references public.couples(id) on delete set null,
  notify_email boolean not null default true, notify_sms boolean not null default false,
  created_at timestamptz not null default now());
grant select, update on public.profiles to authenticated; grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (id uuid primary key default gen_random_uuid(), user_id uuid not null, role public.app_role not null, unique(user_id, role));
grant select on public.user_roles to authenticated; grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;
create or replace function public.my_couple() returns uuid language sql stable security definer set search_path = public as $$
  select couple_id from public.profiles where id = auth.uid() $$;

create policy "own roles" on public.user_roles for select to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "admin manage roles" on public.user_roles for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create policy "read own or spouse profile" on public.profiles for select to authenticated using (id = auth.uid() or (couple_id is not null and couple_id = public.my_couple()) or public.has_role(auth.uid(),'admin'));
create policy "update own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "read own couple" on public.couples for select to authenticated using (id = public.my_couple());

create or replace function public.protect_profile_fields() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if current_setting('app.bypass', true) = 'on' then return new; end if;
  if new.couple_id is distinct from old.couple_id or new.phone_verified is distinct from old.phone_verified then
    if not public.has_role(auth.uid(),'admin') then raise exception 'Not allowed'; end if;
  end if;
  return new;
end $$;
create trigger protect_profile before update on public.profiles for each row execute function public.protect_profile_fields();

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, first_name, last_name, phone) values (new.id, coalesce(new.raw_user_meta_data->>'first_name',''), coalesce(new.raw_user_meta_data->>'last_name',''), nullif(new.raw_user_meta_data->>'phone',''));
  insert into public.user_roles (user_id, role) values (new.id, 'member');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create table public.couple_invites (code text primary key default substr(md5(random()::text),1,8), inviter_id uuid not null default auth.uid(), created_at timestamptz not null default now(), used_at timestamptz);
grant select, insert, delete on public.couple_invites to authenticated; grant all on public.couple_invites to service_role;
alter table public.couple_invites enable row level security;
create policy "own invites" on public.couple_invites for select to authenticated using (inviter_id = auth.uid());
create policy "create invite" on public.couple_invites for insert to authenticated with check (inviter_id = auth.uid());
create policy "delete invite" on public.couple_invites for delete to authenticated using (inviter_id = auth.uid());

create or replace function public.accept_couple_invite(_code text) returns uuid language plpgsql security definer set search_path = public as $$
declare inv record; cid uuid;
begin
  select * into inv from public.couple_invites where code = _code and used_at is null;
  if inv is null then raise exception 'Invalid or used invite code'; end if;
  if inv.inviter_id = auth.uid() then raise exception 'You cannot accept your own invite'; end if;
  if exists (select 1 from public.profiles where id in (inv.inviter_id, auth.uid()) and couple_id is not null) then raise exception 'One of you is already linked'; end if;
  insert into public.couples default values returning id into cid;
  perform set_config('app.bypass','on',true);
  update public.profiles set couple_id = cid where id in (inv.inviter_id, auth.uid());
  update public.couple_invites set used_at = now() where code = _code;
  return cid;
end $$;
create or replace function public.unlink_couple() returns void language plpgsql security definer set search_path = public as $$
declare cid uuid := public.my_couple();
begin
  if cid is null then return; end if;
  perform set_config('app.bypass','on',true);
  update public.profiles set couple_id = null where couple_id = cid;
  update public.couples set status = 'unlinked' where id = cid;
end $$;

create table public.subscriptions (id uuid primary key default gen_random_uuid(), user_id uuid not null, status text not null default 'active', current_period_end timestamptz, created_at timestamptz not null default now());
grant select on public.subscriptions to authenticated; grant all on public.subscriptions to service_role;
alter table public.subscriptions enable row level security;
create policy "own subs" on public.subscriptions for select to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));

create table public.purchases (id uuid primary key default gen_random_uuid(), user_id uuid not null, study_id uuid not null, created_at timestamptz not null default now(), unique(user_id, study_id));
grant select on public.purchases to authenticated; grant all on public.purchases to service_role;
alter table public.purchases enable row level security;
create policy "own purchases" on public.purchases for select to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));

create or replace function public.is_member(_uid uuid) returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(_uid,'admin') or exists (select 1 from public.subscriptions where user_id = _uid and status in ('active','trialing') and (current_period_end is null or current_period_end > now())) $$;

create table public.posts (id uuid primary key default gen_random_uuid(), title text not null, slug text not null unique, excerpt text, body_md text not null default '', cover_url text,
  access text not null default 'free' check (access in ('free','members')), category text, tags text[] not null default '{}', published_at timestamptz default now(), status text not null default 'draft' check (status in ('draft','published')));
grant select on public.posts to anon; grant select, insert, update, delete on public.posts to authenticated; grant all on public.posts to service_role;
alter table public.posts enable row level security;
create policy "admin posts" on public.posts for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "members read posts" on public.posts for select to authenticated using (status='published' and (access='free' or public.is_member(auth.uid())));
create policy "public free posts" on public.posts for select to anon using (status='published' and access='free');

create or replace function public.list_posts() returns table(id uuid, title text, slug text, excerpt text, cover_url text, access text, category text, tags text[], published_at timestamptz)
language sql stable security definer set search_path = public as $$
  select id,title,slug,excerpt,cover_url,access,category,tags,published_at from public.posts where status='published' order by published_at desc $$;
create or replace function public.get_post(_slug text) returns table(id uuid, title text, slug text, excerpt text, cover_url text, access text, category text, tags text[], published_at timestamptz, body_md text, locked boolean)
language plpgsql stable security definer set search_path = public as $$
declare p record; ok boolean;
begin
  select * into p from public.posts where posts.slug = _slug and status='published';
  if p is null then return; end if;
  ok := p.access = 'free' or (auth.uid() is not null and public.is_member(auth.uid()));
  return query select p.id,p.title,p.slug,p.excerpt,p.cover_url,p.access,p.category,p.tags,p.published_at,
    case when ok then p.body_md else array_to_string((regexp_split_to_array(p.body_md, '\s+'))[1:150], ' ') end, not ok;
end $$;
grant execute on function public.list_posts() to anon, authenticated;
grant execute on function public.get_post(text) to anon, authenticated;

create table public.studies (id uuid primary key default gen_random_uuid(), title text not null, slug text not null unique, subtitle text, description text, audience public.study_audience not null default 'everyone',
  duration_label text, cover_url text, price_cents int not null default 0, stripe_price_id text, included_in_membership boolean not null default true, pdf_url text, status text not null default 'draft' check (status in ('draft','published')), sort int not null default 0, created_at timestamptz not null default now());
grant select on public.studies to anon; grant select, insert, update, delete on public.studies to authenticated; grant all on public.studies to service_role;
alter table public.studies enable row level security;
create policy "public studies" on public.studies for select to anon, authenticated using (status='published');
create policy "admin studies" on public.studies for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create or replace function public.has_study_access(_uid uuid, _study uuid) returns boolean language sql stable security definer set search_path = public as $$
  select _uid is not null and (public.has_role(_uid,'admin') or exists(select 1 from public.purchases where user_id=_uid and study_id=_study)
    or (public.is_member(_uid) and exists(select 1 from public.studies where id=_study and included_in_membership))) $$;

create table public.study_weeks (id uuid primary key default gen_random_uuid(), study_id uuid not null references public.studies(id) on delete cascade, week_number int not null, title text not null, summary text);
grant select on public.study_weeks to anon; grant select, insert, update, delete on public.study_weeks to authenticated; grant all on public.study_weeks to service_role;
alter table public.study_weeks enable row level security;
create policy "public weeks" on public.study_weeks for select to anon, authenticated using (true);
create policy "admin weeks" on public.study_weeks for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.videos (id uuid primary key default gen_random_uuid(), title text not null, description text, embed_url text not null, thumbnail_url text, access text not null default 'members' check (access in ('free','members')), published_at timestamptz not null default now());
grant select on public.videos to anon; grant select, insert, update, delete on public.videos to authenticated; grant all on public.videos to service_role;
alter table public.videos enable row level security;
create policy "public free videos" on public.videos for select to anon using (access='free');
create policy "read videos" on public.videos for select to authenticated using (access='free' or public.is_member(auth.uid()));
create policy "admin videos" on public.videos for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.study_days (id uuid primary key default gen_random_uuid(), week_id uuid not null references public.study_weeks(id) on delete cascade, day_number int not null, title text not null,
  scripture_refs text, body_md text not null default '', reflection_questions jsonb not null default '[]', challenge_md text, video_id uuid references public.videos(id) on delete set null, is_sample boolean not null default false);
grant select on public.study_days to anon; grant select, insert, update, delete on public.study_days to authenticated; grant all on public.study_days to service_role;
alter table public.study_days enable row level security;
create policy "sample days" on public.study_days for select to anon, authenticated using (is_sample);
create policy "access days" on public.study_days for select to authenticated using (public.has_study_access(auth.uid(), (select study_id from public.study_weeks w where w.id = week_id)));
create policy "admin days" on public.study_days for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create or replace function public.study_outline(_study uuid) returns table(id uuid, week_id uuid, day_number int, title text, scripture_refs text, is_sample boolean)
language sql stable security definer set search_path = public as $$
  select d.id,d.week_id,d.day_number,d.title,d.scripture_refs,d.is_sample from public.study_days d join public.study_weeks w on w.id=d.week_id where w.study_id=_study order by w.week_number,d.day_number $$;
grant execute on function public.study_outline(uuid) to anon, authenticated;

create table public.study_progress (user_id uuid not null default auth.uid(), study_day_id uuid not null references public.study_days(id) on delete cascade, completed_at timestamptz not null default now(), primary key(user_id, study_day_id));
grant select, insert, delete on public.study_progress to authenticated; grant all on public.study_progress to service_role;
alter table public.study_progress enable row level security;
create policy "own progress" on public.study_progress for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create table public.journal_entries (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid(), study_day_id uuid references public.study_days(id) on delete set null, body text not null,
  visibility text not null default 'private' check (visibility in ('private','shared_with_spouse')), created_at timestamptz not null default now());
grant select, insert, update, delete on public.journal_entries to authenticated; grant all on public.journal_entries to service_role;
alter table public.journal_entries enable row level security;
create policy "own journal" on public.journal_entries for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "spouse shared journal" on public.journal_entries for select to authenticated using (visibility='shared_with_spouse' and public.my_couple() is not null and exists(select 1 from public.profiles p where p.id = user_id and p.couple_id = public.my_couple()));

create table public.events (id uuid primary key default gen_random_uuid(), title text not null, description text, location text, starts_at timestamptz not null, ends_at timestamptz, price_cents int not null default 0, capacity int, cover_url text, created_at timestamptz not null default now());
grant select on public.events to anon; grant select, insert, update, delete on public.events to authenticated; grant all on public.events to service_role;
alter table public.events enable row level security;
create policy "public events" on public.events for select to anon, authenticated using (true);
create policy "admin events" on public.events for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.event_registrations (id uuid primary key default gen_random_uuid(), event_id uuid not null references public.events(id) on delete cascade, user_id uuid not null default auth.uid(), created_at timestamptz not null default now(), unique(event_id,user_id));
grant select, insert, delete on public.event_registrations to authenticated; grant all on public.event_registrations to service_role;
alter table public.event_registrations enable row level security;
create policy "own regs" on public.event_registrations for all to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(),'admin')) with check (user_id = auth.uid());

create table public.email_signups (id uuid primary key default gen_random_uuid(), email text not null unique, created_at timestamptz not null default now());
grant insert on public.email_signups to anon, authenticated; grant select on public.email_signups to authenticated; grant all on public.email_signups to service_role;
alter table public.email_signups enable row level security;
create policy "anyone signup" on public.email_signups for insert to anon, authenticated with check (length(email) between 3 and 255);
create policy "admin read signups" on public.email_signups for select to authenticated using (public.has_role(auth.uid(),'admin'));

create table public.contact_messages (id uuid primary key default gen_random_uuid(), name text not null, email text not null, message text not null, created_at timestamptz not null default now());
grant insert on public.contact_messages to anon, authenticated; grant select on public.contact_messages to authenticated; grant all on public.contact_messages to service_role;
alter table public.contact_messages enable row level security;
create policy "anyone contact" on public.contact_messages for insert to anon, authenticated with check (length(message) between 1 and 5000 and length(name) <= 200 and length(email) <= 255);
create policy "admin read contact" on public.contact_messages for select to authenticated using (public.has_role(auth.uid(),'admin'));

create or replace function public.admin_stats() returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_role(auth.uid(),'admin') then raise exception 'Forbidden'; end if;
  return json_build_object(
    'members', (select count(*) from public.profiles),
    'subscribers', (select count(*) from public.subscriptions where status in ('active','trialing')),
    'registrations', (select count(*) from public.event_registrations),
    'signups', (select count(*) from public.email_signups),
    'sales', (select coalesce(json_agg(json_build_object('title', s.title, 'count', (select count(*) from public.purchases p where p.study_id = s.id))), '[]') from public.studies s));
end $$;

create policy "media read" on storage.objects for select to anon, authenticated using (bucket_id = 'media');
create policy "media admin write" on storage.objects for insert to authenticated with check (bucket_id = 'media' and (public.has_role(auth.uid(),'admin') or ((storage.foldername(name))[1] = 'avatars' and (storage.foldername(name))[2] = auth.uid()::text)));
create policy "media admin update" on storage.objects for update to authenticated using (bucket_id = 'media' and public.has_role(auth.uid(),'admin'));
create policy "media admin delete" on storage.objects for delete to authenticated using (bucket_id = 'media' and public.has_role(auth.uid(),'admin'));

insert into public.studies (title, slug, subtitle, description, audience, duration_label, price_cents, status, sort) values
('Delight by Design','delight-by-design','God''s design for marital intimacy','A couples series walking through Scripture''s vision of oneness, delight, and covenant love — with a companion track on breaking the lies of purity culture.','couples','8 weeks · 5 days/week',4900,'published',1),
('Naked and Unashamed','naked-and-unashamed','An 8-week journey for wives','Daily readings and gentle challenges to help wives receive God''s truth about their bodies, desire, and marriage.','wives','8 weeks · 5 days/week',3900,'published',2),
('Men''s Guide to Biblical Intimacy, Sex & Purity','mens-guide','For husbands who want to lead in love','A 12-week study for husbands on purity, servant leadership, and cherishing their wives.','husbands','12 weeks',4500,'published',3),
('Breaking the Lies of Purity Culture','breaking-the-lies','Replacing shame with truth','A standalone series addressing the fear and shame many believers carry into marriage.','everyone','4 weeks',2900,'published',4),
('Names of God: 30-Day Devotional','names-of-god-30','Know Him by name','A daily web devotional on the names God reveals of Himself, with an optional daily email.','everyone','30 days',1900,'published',5),
('Names of God: 6-Week Workbook','names-of-god-6','Includes group leader guide','A six-week workbook for individuals or small groups.','everyone','6 weeks',2400,'published',6),
('Names of God: 12-Week Workbook','names-of-god-12','Includes group leader guide','A deeper twelve-week workbook with a full leader guide.','everyone','12 weeks',3400,'published',7),
('Names of God: Year-Long Intensive','names-of-god-year','A year in His names','A daily, year-long reading plan with web reader and daily email.','everyone','52 weeks',7900,'published',8);

insert into public.study_weeks (study_id, week_number, title, summary)
select s.id, w.n, case w.n when 1 then 'Created for Oneness' when 2 then 'The Gift of Delight' else 'Walking in Freedom' end,
  'Placeholder summary for week ' || w.n || '.'
from public.studies s cross join (values (1),(2),(3)) as w(n);

insert into public.study_days (week_id, day_number, title, scripture_refs, body_md, reflection_questions, challenge_md, is_sample)
select w.id, d.n, 'Day ' || d.n || ': ' || case d.n when 1 then 'In the Beginning' when 2 then 'Known and Loved' when 3 then 'Covenant Love' when 4 then 'Rest and Delight' else 'Walking Together' end,
  case d.n when 1 then 'Genesis 2:18-25' when 2 then 'Psalm 139:1-14' when 3 then 'Ephesians 5:25-33' when 4 then 'Song of Songs 2:8-13' else 'Ecclesiastes 4:9-12' end,
  E'Before anything was broken, God looked at the man and the woman He had made and called it very good.\n\n> "Therefore a man shall leave his father and his mother and hold fast to his wife, and they shall become one flesh." — Genesis 2:24\n\nToday, read the passage slowly. Notice what God says about **oneness**, and what He does *not* say about shame.\n\nThis is placeholder reading content that the admin can replace in the study editor.',
  '["What stands out to you in today''s passage?","Where have you believed something different from what God says here?","How can you share this with your spouse this week?"]'::jsonb,
  'Pray together for five minutes tonight, thanking God for one specific thing about your spouse.',
  (w.week_number = 1 and d.n = 1)
from public.study_weeks w cross join (values (1),(2),(3),(4),(5)) as d(n);

insert into public.posts (title, slug, excerpt, body_md, access, category, tags, status, published_at) values
('What the Song of Songs Teaches About Delight','song-of-songs-delight','God placed an entire book of love poetry in the canon. Why?','The Song of Songs is one of the most overlooked books in Scripture. ' || repeat('It reminds us that marital love is a gift from God, meant to be enjoyed within covenant. ', 25),'free','Marriage','{song of songs,delight}','published', now() - interval '2 days'),
('Five Lies Purity Culture Told Us','five-lies-purity-culture','Many couples carry shame into the marriage bed. Scripture offers something better.', repeat('Shame was never God''s plan for the marriage covenant. Grace replaces fear with freedom. ', 40),'members','Purity Culture','{purity culture,freedom}','published', now() - interval '6 days'),
('Praying Together as a Couple','praying-together','A simple rhythm for couples who feel awkward praying aloud.', repeat('Start small. Hold hands, read a psalm, and pray one sentence each. ', 30),'free','Spiritual Growth','{prayer}','published', now() - interval '12 days');

insert into public.events (title, description, location, starts_at, ends_at, price_cents, capacity) values
('Spring Marriage Intensive','Two days of teaching, worship, and guided couple time.','Nashville, TN', now() + interval '30 days', now() + interval '31 days', 29900, 40),
('Live Q&A: Intimacy and Scripture','An online evening of honest questions answered from the Word.','Online', now() + interval '12 days', now() + interval '12 days 2 hours', 0, 500),
('Fall Couples Retreat','A restful weekend away to reconnect with God and each other.','Asheville, NC', now() + interval '90 days', now() + interval '92 days', 49900, 30);

insert into public.videos (title, description, embed_url, access) values
('Welcome to Biblical Intimacy','A short welcome and overview of the library.','https://www.youtube.com/embed/ScMzIvxBSi4','free'),
('Session 1: Created for Oneness','Recorded teaching from the spring intensive.','https://www.youtube.com/embed/ScMzIvxBSi4','members');
